@extends('dashboard.master')

@section('title','Admin-FrelanceIT')
@section('body')
@include('dashboard.organs.welcome')

@include('dashboard.organs.content')
@endsection